// ==UserScript==
// @name         slashdot StyleOverride
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://slashdot.org
// @match        https://m.slashdot.org
// @icon         https://www.google.com/s2/favicons?sz=64&domain=slashdot.org
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

let css = `
div.main-content {margin-right:2em !important;}
aside#slashboxes {display:none;}
div#comments.a2commentwrap {margin-right:1em;}
`;

    stylish(css);
})();

