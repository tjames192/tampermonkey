// ==UserScript==
// @name         Add Global functions
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @grant        none
// @include      *
// @run-at       document-start
// ==/UserScript==

(function() {
    'use strict';

    function stylish(...args) {
        let css = args[0];
        let node = document.createElement("style");
        node.type = "text/css";
        node.appendChild(document.createTextNode(css));

        let heads = document.getElementsByTagName("head");
        if (heads.length > 0) {
            heads[0].appendChild(node);
        }
        else {
            // no head yet, stick it whereever
            document.documentElement.appendChild(node);
        }
    }

    const functions = {
        stylish,
    };

    // Place all the functions on the global object, and be careful to
    // not overwrite existing values.
    for(let key in functions) {
        if(functions.hasOwnProperty(key) && !globalThis[key]) {
            globalThis[key] = functions[key];
        }
    }

    // And also put them in a less conspicuous place,
    // in case some website overwrites one of my functions.
    globalThis[Symbol.for('__didev')] = functions;

    window.eval("globalThis = window;");
})();