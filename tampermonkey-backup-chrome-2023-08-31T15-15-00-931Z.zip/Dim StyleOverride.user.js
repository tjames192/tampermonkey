// ==UserScript==
// @name         Dim StyleOverride
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://beta.destinyitemmanager.com/*
// @match        https://destinyitemmanager.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=destinyitemmanager.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    let css = `
body[class^="theme"] {
    --theme-item-polaroid-masterwork: unset;
    --theme-item-polaroid-godroll: var(--theme-accent-primary);
}

    `;

    stylish(css);
})();