// ==UserScript==
// @name         Youtube StyleOverride
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.youtube.com
// @icon         https://www.google.com/s2/favicons?sz=64&domain=youtube.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    let css = `
html:not(.style-scope) {
    --primary-text-color: var(--dark-theme-text-color) !important;
    --primary-background-color: var(--dark-theme-background-color) !important;
    --secondary-text-color: var(--dark-theme-secondary-color) !important;
    --disabled-text-color: var(--dark-theme-disabled-color) !important;
    --divider-color: var(--dark-theme-divider-color) !important;
    --error-color: #dd2c00 !important;
    --primary-color: #3f51b5 !important;
    --dark-theme-background-color: #220537 !important;
    --dark-theme-base-color: #fff !important;
    --dark-theme-text-color: #fff !important;
    --dark-theme-secondary-color: #4d1b62 !important;
    --dark-theme-disabled-color: #390150 !important;
    --dark-theme-divider-color: #1a002e !important;
    --text-primary-color: var(--dark-theme-text-color) !important;
    --default-primary-color: var(--primary-color) !important;
}

  #logo-container .logo,
	.footer-logo-icon,
	#logo-icon,
	#logo-icon-container
  {
    width: 98px !important;
    margin-left: 5px;
    margin-right: 5px;
    content: url("data:image/svg+xml,%3Csvg xmlns:dc='http://purl.org/dc/elements/1.1/' xmlns:cc='http://creativecommons.org/ns%23' xmlns:rdf='http://www.w3.org/1999/02/22-rdf-syntax-ns%23' xmlns:svg='http://www.w3.org/2000/svg' xmlns='http://www.w3.org/2000/svg' id='SVGRoot' version='1.1' viewBox='0 0 846 174' height='80px' width='391px'%3E%3Cdefs id='defs855'%3E%3Cstyle id='style2' /%3E%3C/defs%3E%3Cmetadata id='metadata858'%3E%3Crdf:RDF%3E%3Ccc:Work rdf:about=''%3E%3Cdc:format%3Eimage/svg+xml%3C/dc:format%3E%3Cdc:type rdf:resource='http://purl.org/dc/dcmitype/StillImage' /%3E%3Cdc:title%3E%3C/dc:title%3E%3C/cc:Work%3E%3C/rdf:RDF%3E%3C/metadata%3E%3Cg id='layer1'%3E%3Cg transform='translate(0,0.36)' data-name='Layer 2' id='Layer_2'%3E%3Cg data-name='Layer 1' id='Layer_1-2'%3E%3Cpath style='fill:%23c100ff' id='path6' d='M 242.88,27.11 A 31.07,31.07 0 0 0 220.95,5.18 C 201.6,0 124,0 124,0 124,0 46.46,0 27.11,5.18 A 31.07,31.07 0 0 0 5.18,27.11 C 0,46.46 0,86.82 0,86.82 c 0,0 0,40.36 5.18,59.71 a 31.07,31.07 0 0 0 21.93,21.93 c 19.35,5.18 96.92,5.18 96.92,5.18 0,0 77.57,0 96.92,-5.18 a 31.07,31.07 0 0 0 21.93,-21.93 c 5.18,-19.35 5.18,-59.71 5.18,-59.71 0,0 0,-40.36 -5.18,-59.71 z' /%3E%3Cpath style='fill:%23ffffff' id='path8' d='M 99.22,124.03 163.67,86.82 99.22,49.61 Z' /%3E%3Cpath style='fill:%23282828' id='path10' d='m 358.29,55.1 v 6 c 0,30 -13.3,47.53 -42.39,47.53 h -4.43 v 52.5 H 287.71 V 12.36 H 318 c 27.7,0 40.29,11.71 40.29,42.74 z m -25,2.13 c 0,-21.64 -3.9,-26.78 -17.38,-26.78 h -4.43 v 60.48 h 4.08 c 12.77,0 17.74,-9.22 17.74,-29.26 z m 81.22,-6.56 -1.24,28.2 c -10.11,-2.13 -18.45,-0.53 -22.17,6 v 76.26 H 367.52 V 52.44 h 18.8 L 388.45,76 h 0.89 c 2.48,-17.2 10.46,-25.89 20.75,-25.89 a 22.84,22.84 0 0 1 4.42,0.56 z M 441.64,115 v 5.5 c 0,19.16 1.06,25.72 9.22,25.72 7.8,0 9.58,-6 9.75,-18.44 l 21.1,1.24 c 1.6,23.41 -10.64,33.87 -31.39,33.87 -25.18,0 -32.63,-16.49 -32.63,-46.46 v -19 c 0,-31.57 8.34,-47 33.34,-47 25.18,0 31.57,13.12 31.57,45.93 V 115 Z m 0,-22.35 v 7.8 h 17.91 V 92.7 c 0,-20 -1.42,-25.72 -9,-25.72 -7.58,0 -8.91,5.86 -8.91,25.72 z M 604.45,79 v 82.11 H 580 V 80.82 c 0,-8.87 -2.31,-13.3 -7.63,-13.3 -4.26,0 -8.16,2.48 -10.82,7.09 a 35.59,35.59 0 0 1 0.18,4.43 v 82.11 H 537.24 V 80.82 c 0,-8.87 -2.31,-13.3 -7.63,-13.3 -4.26,0 -8,2.48 -10.64,6.92 v 86.72 H 494.5 V 52.44 h 19.33 L 516,66.28 h 0.35 c 5.5,-10.46 14.37,-16.14 24.83,-16.14 10.29,0 16.14,5.14 18.8,14.37 5.68,-9.4 14.19,-14.37 23.94,-14.37 14.86,0 20.53,10.64 20.53,28.86 z m 12.24,-54.4 c 0,-11.71 4.26,-15.07 13.3,-15.07 9.22,0 13.3,3.9 13.3,15.07 0,12.06 -4.08,15.08 -13.3,15.08 -9.04,-0.01 -13.3,-3.02 -13.3,-15.08 z m 1.42,27.84 h 23.41 v 108.72 h -23.41 z m 103.39,0 v 108.72 h -19.15 l -2.13,-13.3 h -0.53 c -5.5,10.64 -13.48,15.07 -23.41,15.07 -14.54,0 -21.11,-9.22 -21.11,-29.26 V 52.44 h 24.47 v 79.81 c 0,9.58 2,13.48 6.92,13.48 A 12.09,12.09 0 0 0 697,138.81 V 52.44 Z M 845.64,79 v 82.11 H 821.17 V 80.82 c 0,-8.87 -2.31,-13.3 -7.63,-13.3 -4.26,0 -8.16,2.48 -10.82,7.09 A 35.59,35.59 0 0 1 802.9,79 v 82.11 H 778.43 V 80.82 c 0,-8.87 -2.31,-13.3 -7.63,-13.3 -4.26,0 -8,2.48 -10.64,6.92 v 86.72 H 735.69 V 52.44 H 755 l 2.13,13.83 h 0.35 c 5.5,-10.46 14.37,-16.14 24.83,-16.14 10.29,0 16.14,5.14 18.8,14.37 5.68,-9.4 14.19,-14.37 23.94,-14.37 14.95,0.01 20.59,10.65 20.59,28.87 z' /%3E%3C/g%3E%3C/g%3E%3C/g%3E%3C/svg%3E%0A") !important;
  }

  html[dark] #logo-icon,
	html[dark] #logo-icon-container
  {
    width: 98px !important;
    content: url("data:image/svg+xml,%3Csvg xmlns:dc='http://purl.org/dc/elements/1.1/' xmlns:cc='http://creativecommons.org/ns%23' xmlns:rdf='http://www.w3.org/1999/02/22-rdf-syntax-ns%23' xmlns:svg='http://www.w3.org/2000/svg' xmlns='http://www.w3.org/2000/svg' id='SVGRoot' version='1.1' viewBox='0 0 846 174' height='24px' width='98px'%3E%3Cdefs id='defs855'%3E%3Cstyle id='style2' /%3E%3C/defs%3E%3Cmetadata id='metadata858'%3E%3Crdf:RDF%3E%3Ccc:Work rdf:about=''%3E%3Cdc:format%3Eimage/svg+xml%3C/dc:format%3E%3Cdc:type rdf:resource='http://purl.org/dc/dcmitype/StillImage' /%3E%3Cdc:title%3E%3C/dc:title%3E%3C/cc:Work%3E%3C/rdf:RDF%3E%3C/metadata%3E%3Cg id='layer1'%3E%3Cg transform='translate(0,0.36)' data-name='Layer 2' id='Layer_2'%3E%3Cg data-name='Layer 1' id='Layer_1-2'%3E%3Cpath style='fill:%23c100ff' id='path6' d='M 242.88,27.11 A 31.07,31.07 0 0 0 220.95,5.18 C 201.6,0 124,0 124,0 124,0 46.46,0 27.11,5.18 A 31.07,31.07 0 0 0 5.18,27.11 C 0,46.46 0,86.82 0,86.82 c 0,0 0,40.36 5.18,59.71 a 31.07,31.07 0 0 0 21.93,21.93 c 19.35,5.18 96.92,5.18 96.92,5.18 0,0 77.57,0 96.92,-5.18 a 31.07,31.07 0 0 0 21.93,-21.93 c 5.18,-19.35 5.18,-59.71 5.18,-59.71 0,0 0,-40.36 -5.18,-59.71 z' /%3E%3Cpath style='fill:%23ffffff' id='path8' d='M 99.22,124.03 163.67,86.82 99.22,49.61 Z' /%3E%3Cpath style='fill:%23ffffff' id='path10' d='m 358.29,55.1 v 6 c 0,30 -13.3,47.53 -42.39,47.53 h -4.43 v 52.5 H 287.71 V 12.36 H 318 c 27.7,0 40.29,11.71 40.29,42.74 z m -25,2.13 c 0,-21.64 -3.9,-26.78 -17.38,-26.78 h -4.43 v 60.48 h 4.08 c 12.77,0 17.74,-9.22 17.74,-29.26 z m 81.22,-6.56 -1.24,28.2 c -10.11,-2.13 -18.45,-0.53 -22.17,6 v 76.26 H 367.52 V 52.44 h 18.8 L 388.45,76 h 0.89 c 2.48,-17.2 10.46,-25.89 20.75,-25.89 a 22.84,22.84 0 0 1 4.42,0.56 z M 441.64,115 v 5.5 c 0,19.16 1.06,25.72 9.22,25.72 7.8,0 9.58,-6 9.75,-18.44 l 21.1,1.24 c 1.6,23.41 -10.64,33.87 -31.39,33.87 -25.18,0 -32.63,-16.49 -32.63,-46.46 v -19 c 0,-31.57 8.34,-47 33.34,-47 25.18,0 31.57,13.12 31.57,45.93 V 115 Z m 0,-22.35 v 7.8 h 17.91 V 92.7 c 0,-20 -1.42,-25.72 -9,-25.72 -7.58,0 -8.91,5.86 -8.91,25.72 z M 604.45,79 v 82.11 H 580 V 80.82 c 0,-8.87 -2.31,-13.3 -7.63,-13.3 -4.26,0 -8.16,2.48 -10.82,7.09 a 35.59,35.59 0 0 1 0.18,4.43 v 82.11 H 537.24 V 80.82 c 0,-8.87 -2.31,-13.3 -7.63,-13.3 -4.26,0 -8,2.48 -10.64,6.92 v 86.72 H 494.5 V 52.44 h 19.33 L 516,66.28 h 0.35 c 5.5,-10.46 14.37,-16.14 24.83,-16.14 10.29,0 16.14,5.14 18.8,14.37 5.68,-9.4 14.19,-14.37 23.94,-14.37 14.86,0 20.53,10.64 20.53,28.86 z m 12.24,-54.4 c 0,-11.71 4.26,-15.07 13.3,-15.07 9.22,0 13.3,3.9 13.3,15.07 0,12.06 -4.08,15.08 -13.3,15.08 -9.04,-0.01 -13.3,-3.02 -13.3,-15.08 z m 1.42,27.84 h 23.41 v 108.72 h -23.41 z m 103.39,0 v 108.72 h -19.15 l -2.13,-13.3 h -0.53 c -5.5,10.64 -13.48,15.07 -23.41,15.07 -14.54,0 -21.11,-9.22 -21.11,-29.26 V 52.44 h 24.47 v 79.81 c 0,9.58 2,13.48 6.92,13.48 A 12.09,12.09 0 0 0 697,138.81 V 52.44 Z M 845.64,79 v 82.11 H 821.17 V 80.82 c 0,-8.87 -2.31,-13.3 -7.63,-13.3 -4.26,0 -8.16,2.48 -10.82,7.09 A 35.59,35.59 0 0 1 802.9,79 v 82.11 H 778.43 V 80.82 c 0,-8.87 -2.31,-13.3 -7.63,-13.3 -4.26,0 -8,2.48 -10.64,6.92 v 86.72 H 735.69 V 52.44 H 755 l 2.13,13.83 h 0.35 c 5.5,-10.46 14.37,-16.14 24.83,-16.14 10.29,0 16.14,5.14 18.8,14.37 5.68,-9.4 14.19,-14.37 23.94,-14.37 14.95,0.01 20.59,10.65 20.59,28.87 z' /%3E%3C/g%3E%3C/g%3E%3C/g%3E%3C/svg%3E%0A") !important;
  }
  .yt-spec-icon-badge-shape--type-notification .yt-spec-icon-badge-shape__badge {
      background-color: #c100ff !important;
      color: var(--yt-spec-static-brand-white);
  }
  .skeleton-bg-color
  {
    background-color: #1a002e !important;
    border-color: #0d0017 !important;
    border-bottom: 1px solid #0d0017 !important;
  }
  tp-yt-paper-button.ytd-subscribe-button-renderer {
      background-color: #c100ff !important;
  }
  .watch-skeleton .skeleton-light-border-bottom
  {
    border-bottom: 1px solid #0d0017 !important;
  }

  .masthead-skeleton-icon
  {
    background-color: #1a002e;
  }

  #masthead
  {
    background-color: #1a002e !important;
  }

  path[fill="#FF0000"]
  {
    fill: #C100FF !important;
  }

  div.style-scope.ytd-masthead
  {
    background-color: #1A002E !important;
  }

  #guide-inner-content
  {
    background-color: #1A002E !important;
  }

  ytd-mini-guide-renderer.style-scope.ytd-app
  {
    background-color: #1A002E !important;
  }

  a.yt-simple-endpoint.style-scope.ytd-mini-guide-entry-renderer
  {
    background-color: #1A002E !important;
  }

  iron-selector.style-scope.ytd-feed-filter-chip-bar-renderer
  {
    background-color: #390150 !important;
  }

  html:not(.style-scope)[dark], :not(.style-scope)[dark]
  {
    --yt-spec-brand-background-primary: rgba(57, 1, 80, 0.98) !important;
    --ytd-searchbox-legacy-border-color: hsl(294, 100%, 22%) !important;
    --ytd-searchbox-legacy-button-border-color: hsl(294, 100%, 22%) !important;
  }

  .ytd-guide-renderer
  {
    background-color: #240040 !important;
  }

  .guide-links-primary
  {
    background-color: #1a002e !important;
  }

  .ytd-popup-container
  {
    background-color: #8400A8 !important;
  }

  .ytd-multi-page-menu-renderer
  {
    background-color: #1a002e !important;
  }

  .yt-multi-page-menu-section-renderer
  {
    background-color: #220537!important;
  }

  #guide-content
  {
    background-color: #8400A8 !important;
  }

  .style-scope.ytd-watch
  {
    background-color: #1a002e !important;
  }

  .hide-skeleton
  {
    background-color: #1a002e !important;
  }

  .ytd-page-manager
  {
    background-color: #1a002e !important;
  }

  .ytd-browse
  {
    background-color: #1a002e !important;
  }

  .ytd-playlist-panel-renderer
  {
    background-color: #1a002e !important;
  }

  .ytd-searchbox
  {
    background-color: #1a002e !important;
  }

  #channel-header
  {
    background-color: #8400A8 !important;
  }

  #tabs-inner-container
  {
    background-color: #1a002e !important;
  }

  .yt-notification-action-renderer
  {
    background-color: #8400A8 !important;
  }

  .ytd-backstage-post-renderer
  {
    background-color: #1a002e !important;
  }

  #columns
  {
    background-color: #1a002e !important;
  }

  .ytd-two-column-browse-results-renderer
  {
    background-color: #220537 !important;
  }

  .ytd-info-panel-content-renderer.style-scope.ytd-watch-flexy
  {
    background-color: #220537 !important;
  }
/* Background principal */
  .ytd-topic-channel-details-renderer, #channel-details, .ytd-rich-metadata-renderer
  {
    background-color: #460060 !important;
  }


/*Player*/
  #movie_player
  {
    background-color: #220537 !important;
  }

/*Chat*/
  .yt-live-chat-renderer
  {
    background-color: #8400A8 !important;
  }

  .yt-live-chat-item-list-renderer
  {
    background-color: #1a002e !important;
  }

  .ytd-toggle-button-renderer
  {
    background-color: #1a002e !important;
  }

  .ytd-live-chat-frame
  {
    background-color: #8400A8 !important;
  }

  .yt-dropdown-menu
  {
    background-color: #370046 !important;
  }

  .settings-card
  {
    background-color: #1a002e !important;
  }

  .panel-close-button
  {
    background-color: #8400A8 !important;
  }

/*ScrollBar*/
  ::-webkit-scrollbar,
::-webkit-scrollbar-corner,
::-webkit-scrollbar-track-piece
  {
    background: #0d0017 !important;
  }

  ::-webkit-scrollbar
  {
    width: 6px !important;
    height: 6px !important;
  }

  ::-webkit-scrollbar-thumb
  {
    border-radius: 0px !important;
    box-shadow: inset 0 0 0px #390150;
    border: 0px solid #390150 !important;
  }

  ::-webkit-scrollbar-thumb:horizontal
  {
    background: linear-gradient(to right, #390150, #390150, #390150, #390150);
  }

  ::-webkit-scrollbar-thumb:vertical
  {
    background: linear-gradient(#390150, #390150, #390150, #390150);
  }

  body
  {
    font-family: 'Open Sans', sans-serif !important;
  }

/*Sidebar icons*/
  ytd-guide-entry-renderer[active] .guide-icon.ytd-guide-entry-renderer
  {
    fill: #C900FF !important;
  }

  .ytp-play-progress,
  .ytp-scrubber-button.ytp-swatch-background-color,
  #notification-count,
  #subscribe-button > ytd-subscribe-button-renderer > paper-button,
  paper-button.ytd-subscribe-button-renderer,
  .style-scope.ytd-thumbnail-overlay-resume-playback-renderer,
  .ytp-menuitem[aria-checked="true"] .ytp-menuitem-toggle-checkbox,
  paper-toggle-button[checked]:not([disabled]) .toggle-bar.paper-toggle-button,
  #progress
  {
    background-color: #C900FF !important;
  }

 /*Live Now badge, Player settings quality text */

  .badge-style-type-live-now.style-scope.ytd-badge-supported-renderer,
  .ytp-swatch-color
  {
    color: #C900FF !important;
    border-color: #C900FF;
  }
  /*Sub-button text*/

  paper-button.ytd-subscribe-button-renderer
  {
    color: #F6DAFF !important;
  }
  /*Player quality badges [OLD]*/

  .ytp-red2 .ytp-settings-button.ytp-hd-quality-badge:after,
  .ytp-red2 .ytp-settings-button.ytp-4k-quality-badge:after,
  .ytp-red2 .ytp-settings-button.ytp-5k-quality-badge:after,
  .ytp-red2 .ytp-settings-button.ytp-8k-quality-badge:after,
  .ytp-red2 .ytp-settings-button.ytp-3d-badge:after
  {
    background-color: #C900FF !important;
  }
  /*Player quality badges*/

  .ytp-settings-button.ytp-hd-quality-badge:after,
  .ytp-settings-button.ytp-4k-quality-badge:after,
  .ytp-settings-button.ytp-5k-quality-badge:after,
  .ytp-settings-button.ytp-8k-quality-badge:after
  {
    background-color: #C900FF !important;
  }
  /*Volume slider*/

  .ytp-volume-slider-handle:before,
  .ytp-volume-slider-handle
  {
    background-color: #C900FF !important;
  }

  .ytp-volume-slider-handle:after
  {
    background-color: #8F9091 !important;
    z-index: -1;
  }
  /*Youtube Logo*/

  #logo-icon-container > svg > g > g:nth-child(1) > path
  {
    fill: #C900FF !important;
  }
    `;

    stylish(css);
})();